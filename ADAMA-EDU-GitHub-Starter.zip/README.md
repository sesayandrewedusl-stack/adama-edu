# ADAMA EDU — School Management System starter

**Empowering Every School. Inspiring Every Student.**  
Developed by Andrew Sesay 🇸🇱

This is a GitHub-ready starter UI for ADAMA EDU. It includes a responsive 3D-inspired landing page, school registration form, login screen, and dashboard preview. It is **frontend-only**: authentication, email OTP (30-second expiry), tenant isolation, database persistence, payments, and report-card generation need a backend before production use.

## Run locally
1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

## Publish to GitHub
1. Create a new repository on GitHub (e.g. `adama-edu`).
2. Upload/extract these files into the repository, or use Git:
   ```bash
   git init
   git add .
   git commit -m "Initial ADAMA EDU starter"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/adama-edu.git
   git push -u origin main
   ```
3. To publish the frontend, connect the GitHub repo to Vercel or Netlify and deploy. This starter does not yet connect to a live backend.

## Important before real schools use it
- Never store passwords or OTPs in frontend code/local storage.
- Implement server-side OTP generation, hashing, expiry, single-use validation, rate limits, and email delivery.
- Implement per-school tenant authorization and role permissions on the server.
- Use a database, backups, audit logs, HTTPS, and secure environment variables.
- Provision the platform Super Admin privately (not through public registration).
