import React, { useState } from 'react';
import { GraduationCap, ShieldCheck, Users, BookOpen, Wallet, BarChart3, ArrowRight, Menu, X, Globe, Mail, Lock, School, CheckCircle2, Sparkles } from 'lucide-react';

const features = [
  { icon: Users, title: 'Student records', text: 'Keep student profiles, admissions, class placement and history organized.' },
  { icon: BookOpen, title: 'Results & report cards', text: 'Teachers enter marks; students view totals, averages and report cards.' },
  { icon: Wallet, title: 'School finance', text: 'Track fees, receipts, balances, scholarships and expenses in SLE.' },
  { icon: BarChart3, title: 'Clear insights', text: 'See attendance, academic performance and school activity in one place.' },
];

function App() {
  const [page, setPage] = useState('home');
  const [mobile, setMobile] = useState(false);
  const [notice, setNotice] = useState('');
  const [accepted, setAccepted] = useState(false);
  const [form, setForm] = useState({ school:'', admin:'', email:'', phone:'', address:'', username:'', password:'' });
  const [login, setLogin] = useState({ username:'', password:'' });
  const update = (key, value) => setForm(p => ({...p, [key]:value}));

  const go = (next) => { setPage(next); setMobile(false); setNotice(''); window.scrollTo({top:0,behavior:'smooth'}); };
  const submitRegister = (e) => { e.preventDefault(); setNotice(accepted ? 'Demo form checked. Connect the backend to create your school and send the 30-second email OTP.' : 'Please accept the Terms & Conditions first.'); };
  const submitLogin = (e) => { e.preventDefault(); setNotice('Demo login only. Authentication is not connected yet.'); };

  return <div className="app-shell">
    <nav className="nav">
      <button className="brand" onClick={() => go('home')} aria-label="ADAMA EDU home">
        <span className="brand-mark"><GraduationCap size={24}/></span><span>ADAMA <b>EDU</b><small>School Management</small></span>
      </button>
      <div className={`nav-links ${mobile?'show':''}`}>
        <button onClick={()=>go('home')}>Home</button><a href="#features" onClick={()=>setMobile(false)}>Features</a><a href="#about" onClick={()=>setMobile(false)}>About</a>
        <button className="nav-login" onClick={()=>go('login')}>Log in</button><button className="nav-cta" onClick={()=>go('register')}>Register school <ArrowRight size={16}/></button>
      </div>
      <button className="menu-toggle" onClick={()=>setMobile(!mobile)}>{mobile?<X/>:<Menu/>}</button>
    </nav>

    {page==='home' && <>
      <header className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"></span> BUILT FOR SCHOOLS IN SIERRA LEONE <span className="flag">🇸🇱</span></div>
          <h1>One platform.<br/><em>Every school.</em><br/>A brighter future.</h1>
          <p className="hero-text">Manage students, teachers, classes, attendance, results and school finances—all from one secure workspace.</p>
          <div className="hero-actions"><button className="primary" onClick={()=>go('register')}>Register your school <ArrowRight size={18}/></button><button className="secondary" onClick={()=>go('login')}>Explore the portal</button></div>
          <div className="trust"><ShieldCheck size={18}/> Designed around school roles and secure access <span>•</span> 🇸🇱 Sierra Leone
          </div>
        </div>
        <div className="hero-visual">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="glow"></div>
          <div className="dashboard-card">
            <div className="dash-top"><div><span className="mini-label">SCHOOL OVERVIEW</span><h3>Good morning, Admin 👋</h3></div><span className="live-dot">● LIVE PREVIEW</span></div>
            <div className="stats">
              <div className="stat"><span className="stat-icon blue"><Users size={17}/></span><small>Students</small><strong>1,248</strong><span className="positive">↑ 8.2%</span></div>
              <div className="stat"><span className="stat-icon purple"><BookOpen size={17}/></span><small>Teachers</small><strong>64</strong><span className="positive">↑ 4 new</span></div>
              <div className="stat"><span className="stat-icon green"><CheckCircle2 size={17}/></span><small>Attendance</small><strong>94.6%</strong><span className="positive">Today</span></div>
            </div>
            <div className="chart-box"><div className="chart-heading"><b>Academic activity</b><span>This term</span></div><div className="bars">{[36,52,43,70,58,83,64,94,72,86,66,100].map((h,i)=><span key={i} style={{height:`${h}%`}} className={i===7?'bar-highlight':''}/>)}</div><div className="chart-labels"><span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span></div></div>
            <div className="floating-note note-one"><span className="note-icon"><CheckCircle2 size={17}/></span><div><b>Results saved</b><small>Class 9A · Mathematics</small></div></div>
            <div className="floating-note note-two"><span className="note-icon purple-note"><Wallet size={17}/></span><div><b>Fee payment</b><small>SLE 2,500 received</small></div></div>
          </div>
      </header>
      <section className="mini-strip"><div><strong>One school at a time</strong><span>Each school gets its own private workspace.</span></div><div><strong>One connected system</strong><span>Academics, attendance and finance together.</span></div><div><strong>Made for Sierra Leone</strong><span>Local context and SLE currency.</span></div></section>
      <section className="section features" id="features"><div className="section-head"><span className="section-kicker">WHAT YOU CAN MANAGE</span><h2>Everything your school needs,<br/><em>in one place.</em></h2><p>Less paperwork. Better visibility. More time for learning.</p></div><div className="feature-grid">{features.map(({icon:Icon,title,text})=><article className="feature-card" key={title}><span className="feature-icon"><Icon size={23}/></span><h3>{title}</h3><p>{text}</p><span className="card-arrow"><ArrowRight size={17}/></span></article>)}</div></section>
      <section className="section about" id="about"><div className="about-orb"><div className="about-logo"><GraduationCap size={42}/><span>ADAMA<br/><b>EDU</b></span></div><div className="orbit-label">LEARNING • GROWTH • COMMUNITY</div></div><div className="about-copy"><span className="section-kicker">OUR PURPOSE</span><h2>Technology that opens<br/>doors for <em>every learner.</em></h2><p>ADAMA EDU is envisioned as a school-management platform that supports schools of different sizes and resources, helping educators focus on students while administrators work with clear, organized information.</p><button className="text-link" onClick={()=>go('register')}>Start with your school <ArrowRight size={17}/></button></div></section>
      <section className="cta"><Sparkles size={22}/><h2>Ready to bring your school<br/>into one connected system?</h2><p>Start your ADAMA EDU school registration.</p><button className="primary light" onClick={()=>go('register')}>Register a school <ArrowRight size={18}/></button></section>
    </>}
    {page==='register' && <main className="auth-wrap"><div className="auth-intro"><span className="section-kicker">SCHOOL ONBOARDING · 🇸🇱</span><h1>Bring your school<br/><em>on board.</em></h1><p>Register your school workspace. Your school administrator will be able to manage its own staff, students and records.</p><div className="auth-benefit"><ShieldCheck/><span><b>Private school workspace</b><small>School data should remain separated and protected.</small></span></div><div className="auth-benefit"><Mail/><span><b>Email verification</b><small>Planned 6-digit code with a 30-second expiry.</small></span></div></div>
      <form className="auth-card" onSubmit={submitRegister}><div className="form-heading"><span className="form-icon"><School/></span><div><h2>Register your school</h2><p>Fields marked * are required</p></div></div>
        <div className="form-grid"><label>School name *<input required value={form.school} onChange={e=>update('school',e.target.value)} placeholder="e.g. Adama Academy"/></label><label>Administrator name *<input required value={form.admin} onChange={e=>update('admin',e.target.value)} placeholder="Full name"/></label><label>Email address *<input required type="email" value={form.email} onChange={e=>update('email',e.target.value)} placeholder="admin@school.com"/></label><label>Phone number<input value={form.phone} onChange={e=>update('phone',e.target.value)} placeholder="+232 ..."/></label><label className="wide">School address<input value={form.address} onChange={e=>update('address',e.target.value)} placeholder="Town / district, Sierra Leone"/></label><label>Admin username *<input required value={form.username} onChange={e=>update('username',e.target.value)} placeholder="Choose a username"/></label><label>Password *<input required minLength="8" type="password" value={form.password} onChange={e=>update('password',e.target.value)} placeholder="At least 8 characters"/></label></div>
        <label className="terms"><input type="checkbox" checked={accepted} onChange={e=>setAccepted(e.target.checked)}/><span>I agree to the <a href="#terms" onClick={e=>{e.preventDefault();setNotice('Terms preview: use ADAMA EDU responsibly, protect student data, and follow applicable school/privacy rules. A complete legal Terms & Conditions must be supplied before launch.')}}>Terms & Conditions</a> *</span></label>
        <button className="primary full" type="submit">Continue to email verification <ArrowRight size={18}/></button>{notice&&<div className="notice">{notice}</div>}<p className="form-foot">Already registered? <button type="button" onClick={()=>go('login')}>Log in</button></p></form></main>}
    {page==='login' && <main className="auth-wrap login-wrap"><div className="auth-intro"><span className="section-kicker">WELCOME BACK · 🇸🇱</span><h1>Your school.<br/><em>Your workspace.</em></h1><p>Sign in to access your ADAMA EDU portal.</p><div className="login-quote">“Empowering Every School. Inspiring Every Student.”</div></div><form className="auth-card login-card" onSubmit={submitLogin}><div className="form-heading"><span className="form-icon"><Lock/></span><div><h2>Sign in</h2><p>Use your school account credentials</p></div></div><label>Username<input required value={login.username} onChange={e=>setLogin(p=>({...p,username:e.target.value}))} placeholder="Your username"/></label><label>Password<input required type="password" value={login.password} onChange={e=>setLogin(p=>({...p,password:e.target.value}))} placeholder="Your password"/></label><button className="forgot" type="button" onClick={()=>setNotice('Password recovery will send a secure, single-use email OTP after backend integration.')}>Forgot password?</button><button className="primary full" type="submit">Log in securely <ArrowRight size={18}/></button>{notice&&<div className="notice">{notice}</div>}<p className="form-foot">New school? <button type="button" onClick={()=>go('register')}>Register here</button></p></form></main>}
    <footer><div className="footer-brand"><span className="brand-mark"><GraduationCap size={22}/></span><b>ADAMA EDU</b><span className="flag">🇸🇱</span></div><p>Empowering Every School. Inspiring Every Student.</p><div className="footer-bottom"><span>© {new Date().getFullYear()} ADAMA EDU</span><span>Developed by <b>Andrew Sesay</b> · Sierra Leone 🇸🇱</span><span><Globe size={14}/> Made for education</span></div></footer>
  </div>;
}
export default App;
